canvas = document.getElementById("myCanvas");
ctx = canvas.getContext("2d");

sh = 150;
sl = 100;

fC = "a.jpeg";
// faltou um ponto e virgula abaixo
s = "transferir.jpeg";

sy = 10;
sx = 10;

function add() {
    ni = new Image();
    ni.onload = ufc;
    ni.src = fC;

    ns = new Image();
    ns.onload = usc;
    ns.src = s;

}

function ufc() {
    ctx.drawImage(ni, 0, 0, canvas.width, canvas.height);
}
function usc() {
    ctx.drawImage(ns, sx, sy, sl, sh);
}

window.addEventListener("keydown", myKeyDown);

function myKeyDown(e) {
    //e.keyCode, o k é minúsculo
    keyPressed = e.keyCode;
    if (keyPressed == '37') {
        left();
    }

    if (keyPressed == '38') {
        up();
    }
    if (keyPressed == '39') {
        right();
    }
    if (keyPressed == '40') {
        down();
        console.log("down");
    }
}

//adicionei o if para não sair da tela!
function left() {
    if (sx >= 0) {
        sx = sx - 10;
        ufc();
        usc();
    }
}

function up() {
    if (sy >= 0) {
        sy = sy - 10;
        ufc();
        usc();
    }
}

function right() {
    if (sx <= 700) {
        sx = sx + 10;
        ufc();
        usc();
    }
}

function down() {
    if (sy <= 500) {
        sy = sy + 10;
        ufc();
        usc();
    }
}

